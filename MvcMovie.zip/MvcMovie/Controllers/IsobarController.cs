﻿//using Microsoft.AspNetCore.Mvc;
//using System.Text.Encodings.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MvcMovie.Data;
using MvcMovie.Models;

namespace MvcMovie.Controllers
{
    public class IsobarController : Controller
    {
        private readonly MvcMovieContext _context;

        public IsobarController(MvcMovieContext context)
        {
            _context = context;
        }

        // GET: /Home/
        public IActionResult Index()
        {
            return View();
        }

        // GET: Movies in Menu
        public async Task<IActionResult> Menus(string movieBrand, string searchString)
        {
            // Use LINQ to get list of genres.
            IQueryable<string> brandQuery = from m in _context.Movie
                                            orderby m.Brand
                                            select m.Brand;

            var movies = from m in _context.Movie
                         select m;

            if (!string.IsNullOrEmpty(searchString))
            {
                movies = movies.Where(s => s.Name.Contains(searchString));
            }

            if (!string.IsNullOrEmpty(movieBrand))
            {
                movies = movies.Where(x => x.Name == movieBrand);
            }

            var movieBrandVM = new MovieBrandViewModel
            {
                Brands = new SelectList(await brandQuery.Distinct().ToListAsync()),
                Movies = await movies.ToListAsync()
            };

            return View(movieBrandVM);
        }

        public IActionResult Events()
        {
            return View();
        }

        public IActionResult Aboutus()
        {
            return View();
        }

        public IActionResult Contactus()
        {
            return View();
        }

        //// GET: /HelloWorld/Welcome/ 
        //// Requires using System.Text.Encodings.Web;
        //public IActionResult Welcome(string name, int numTimes = 1)
        //{
        //    ViewData["Message"] = "Hello " + name;
        //    ViewData["NumTimes"] = numTimes;

        //    return View();
        //}
    }
}