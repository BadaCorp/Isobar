﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;

namespace MvcMovie.Models
{
    public class MovieBrandViewModel
    {
        public List<Movie> Movies { get; set; }
        public SelectList Brands { get; set; }
        public string ProductBrand { get; set; }
        public string SearchString { get; set; }
    }
}