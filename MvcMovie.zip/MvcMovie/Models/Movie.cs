﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MvcMovie.Models
{
    public class Movie
    {
        public int ID { get; set; }

        [StringLength(30, MinimumLength = 3)]
        [Required]
        public string Name { get; set; }

        [Range(1, 100)]
        [DataType(DataType.Currency)]
        [Column(TypeName = "double(18, 2)")]
        public double Price { get; set; }

        [StringLength(10, MinimumLength = 3)]
        [Required]
        public String Brand { get; set; }

        [StringLength(60, MinimumLength = 3)]
        [Required]
        [Display(Name = "File Name")]
        public String Filename { get; set; }

        [Required]
        [Display(Name = "Date Added")]
        [DataType(DataType.Date)]
        public DateTime DateAdded { get; set; }
    }
}